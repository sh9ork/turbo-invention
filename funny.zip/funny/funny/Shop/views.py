from django.http import HttpResponse
from django.shortcuts import render

def main_page(request):
    return HttpResponse('<h1 style="color: red">Main Page!!!</h1>')