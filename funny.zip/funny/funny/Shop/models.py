from django.db import models

def product_fields():
    fields_type = [
        ('побутова техніка', 'побутова техніка'),
        ('Ноутбуки та комп’ютери', 'Ноутбуки та комп’ютери'),
        ('Товари для геймерів', 'Товари для геймерів'),
        ('Товари для дому', 'Товари для дому'),
        ('Зоотовари', 'Зоотовари')
    ]
    return fields_type
class Product(models.Model):
    name = models.CharField(max_length=40)
    type = models.CharField(max_length=30,
                            choices=product_fields(),
                            default=' ')
    timestamp = models.DateTimeField(auto_now_add=True)
    description = models.TextField()
    update = models.DateTimeField(auto_now=True)
    price = models.DecimalField(max_digits=15,
                                decimal_places=2)

    def __str__(self):
        return self.name

