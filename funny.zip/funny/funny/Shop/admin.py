from django.contrib import admin
from Shop.models import Product

class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'type', 'price', 'update', 'timestamp')
    list_filter = ('price', 'type')
    list_editable = ('price', 'type', 'name')
    list_display_links = ('update', )


admin.site.register(Product, ProductAdmin)

